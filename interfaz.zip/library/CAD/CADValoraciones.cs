﻿using System;
using library.EN;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library.CAD
{
    class CADValoraciones
    {
        public CADValoraciones() { }

        public bool createValoraciones(ENValoraciones en) { return false; }

        public bool readValoracioneses(ENValoraciones en) { return false; }

        public bool deleteValoracioneses(ENValoraciones en) { return false; }

        public bool updateValoracioneses(ENValoraciones en) { return false; }

    }
}
