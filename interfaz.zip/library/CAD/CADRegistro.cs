﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using library.EN;

namespace library.CAD;
{

    class CADRegistro
    {
        private string constring;

        public CADRegistro()
        {
            //Iniciamos la conexión "constring -- connection"
        }

        public bool createUsuario(ENRegistro en)
        {
            //Implementariamos la función 
        }


}
