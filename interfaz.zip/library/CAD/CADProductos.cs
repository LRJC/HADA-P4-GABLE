﻿using System;
using library.EN;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library.CAD
{
    class CADProductos
    {
        public bool readProductos(ENProductos en) { return false; }//Pablo

        public bool createProductos(ENProductos en) { return false; }

        public bool deleteProductos(ENProductos en) { return false; }

        public bool updateProductos(ENProductos en) { return false; }

    }
}
