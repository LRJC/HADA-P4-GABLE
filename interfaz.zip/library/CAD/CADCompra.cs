﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using library.EN;

namespace library.CAD
{
	class CADCompra
	{
		private string constring;
		public CADCompra()
		{
			//Iniciamos la conexión
		}

		public bool doComprar(ENCompra en)
        {
			//Aqui implementariamos la funcion...
        }
	}

}
