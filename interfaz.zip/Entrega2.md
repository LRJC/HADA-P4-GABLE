# Comentarios de la entrega 2 (Entrega de EN/CAD y esquema de la BD)

- En el esquema faltan cosas. Por ejemplo, falta el concepto de compra (o pedido), y el de líneas de pedido que estará relacionado con el producto.

- No se si llegaréis al requisito de dos entidades por miembro del equipo. Tenedlo en cuenta. En la entrega final tendréis que indicar quien ha hecho cada cosa. 

- Faltaría detallar más la definición de las tareas. Tenéis que definir las tareas con antelación a las entregas, y modificar el estado(to, in progress, etc) de cada una de ellas en la pizarra del proyecto. 


