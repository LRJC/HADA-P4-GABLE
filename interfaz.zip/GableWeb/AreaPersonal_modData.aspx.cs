﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GableWeb
{
    public partial class AreaPersonal_modData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonCambiarContra_Click(object sender, EventArgs e)
        {
            //actualizar la contraseña en la bbdd
        }

        protected void ButtonCambiarDatosPersonales_Click(object sender, EventArgs e)
        {
            //actualizar los datos personales en la bbdd
        }

        protected void ButtonCambiarInfoPagos_Click(object sender, EventArgs e)
        {
            //actualizar la informacion de pago en la bbdd
        }
    }
}